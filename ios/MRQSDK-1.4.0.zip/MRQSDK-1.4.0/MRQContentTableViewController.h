//
//  MRQContentTableViewController.h
//  MRQSDK
//
//  Copyright (c) 2012-2016 MobileRQ. All rights reserved.
//

#import "MRQSDK.h"
#import "MRQViewController.h"
#import <UIKit/UIKit.h>

/**
 MRQContentTableViewController displays MRQ content in as a vertical scrolling list. The list is implemented using a UITableView.
 Each content item is displayed in a UITableViewCell. The content is automatically scaled to fit the width of the UITableViewCell.
 The content height is automatically scaled to maintain the correct aspect ratio.
 */
@interface MRQContentTableViewController : MRQViewController <UITableViewDelegate, UITableViewDataSource>

/** The UITableView for displaying content. */
@property IBOutlet UITableView *tableView;

@end
