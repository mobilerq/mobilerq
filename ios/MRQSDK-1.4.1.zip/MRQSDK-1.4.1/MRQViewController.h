//
//  MRQViewController.h
//  MRQSDK
//
//  Copyright (c) 2012-2016 MobileRQ. All rights reserved.
//

#import "MRQContentView.h"
#import "MRQSDK.h"
#import "MRQViewController.h"
#import <UIKit/UIKit.h>

/** MRQViewControllerDelegate is a protocol for handling content view and tap events. */
@protocol MRQViewControllerDelegate <NSObject>

/**
 Notification that content has been viewed.
 @param content the MRQContent that was viewed
 @param view the MRQContentView object that captured the view event
 @param sdk the instance of MRQSDK in use by the view
 */
- (void)didViewContent:(MRQContent *)content withView:(MRQContentView *)view withSdk:(MRQSDK *)sdk;

/**
 Notification that content has been tapped.
 @param content the MRQContent that was tapped
 @param view the MRQContentView object that captured the view event
 @param sdk the instance of MRQSDK in use by the view
 */
- (void)didTapContent:(MRQContent *)content withView:(MRQContentView *)view withSdk:(MRQSDK *)sdk;

@end

/**
 Default MRQViewControllerDelegate that implements content view and tap tracking behavior.
 Used by MRQViewController when a delegate has not be explicitly set.
 Content view and tap events are passed to MobileRQ for tracking and analytics.
 Content tap events are also handled by opening the content URL (if present).
 Any implementations of MRQViewControllerDelegate that need these standard behaviors should extend
 MRQViewControllerDefaultDelegate and be sure to call super inside message implementations.
 */
@interface MRQViewControllerDefaultDelegate : NSObject <MRQViewControllerDelegate>

@end

/**
 Abstract base implementation of view controllers that display MobileRQ content.
 MRQViewControllers register for MRQ content update notification messages using NSNotificationCenter.
 These messages are sent by MRQSDK to tell MRQViewControllers to refresh displayed content.

 MRQViewControllers use MRQViewControllerDelegate to notify the application of content view and tap events.
 The default implementation of MRQViewControllerDelegate is MRQViewControllerDefaultDelegate.
 MRQViewControllerDefaultDelegate responds to tap events by attempting to open the creative URL (if present).
 MRQViewControllerDefaultDelegate sends view and tap events to the MRQ backend for tracking and analytics.

 MRQViewControllers can be assigned a slot by calling slotName.
 The slot name is used to filter content displayed in the control.
 If the slot name is set, only content for that slot is displayed in the control.
 If the slot name is not set (default), only content not assigned a slot is displayed in the control.
 */
@interface MRQViewController : UIViewController

/**
  Automatically called when [MRQSDK matchingContent] changes. Calls selectContent with matchingContent. If content has changed since last refresh, updates selectedContent and calls reloadContent:.
 */
- (void)refresh;

/**
 This method implements any view-specific filtering that should occur.
 The passed in content array has already been filtered by MRQ using
 audience matching rules and locally by MRQSDK using slot matching rules.
 @param content array of MRQContent to be filtered
 */
- (NSArray *)selectContent:(NSArray *)content;

/**
 Called when content changes. This function should update the underlying view and display the new content.
 @param content array of MRQContent from the last call to selectContent
 */
- (void)reloadContent:(NSArray *)content;

/** The MRQSDK (default is [MRQSDK shared]) */
@property MRQSDK *mrqsdk;

/**
 Sets the slot name for this controller. Only content assigned the same slot name
 will be displayed. A nil value, which is the default, will only
 display content not assigned a slot.
 */
@property NSString *slotName;

/** The contents selected by the last call to refresh. */
@property(readonly) NSArray *selectedContent;

/** Called to notify applications of interactions with MRQContent. */
@property id<MRQViewControllerDelegate> delegate;

/** This view is automatically used when there is no matching content. */
@property(nonatomic) IBOutlet UIView *noContentView;

@end
