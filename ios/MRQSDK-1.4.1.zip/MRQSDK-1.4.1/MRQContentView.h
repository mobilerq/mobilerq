//
//  MRQContentView.h
//  MRQSDK
//
//  Copyright (c) 2012-2016 MobileRQ. All rights reserved.
//

#import "MRQContent.h"
#import <UIKit/UIKit.h>

/** The MRQContentView extends UIWebView in order to display MobileRQ content. */
@interface MRQContentView : UIWebView <UIWebViewDelegate>

/** The MRQContent class loaded by this MRQContentView. */
@property(readonly) MRQContent *content;

/** Load content into the UIWebView.
    @param content The content to load */
- (void)loadContent:(MRQContent *)content;

@end
