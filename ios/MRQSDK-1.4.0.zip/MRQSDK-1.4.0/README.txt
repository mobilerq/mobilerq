# MobileRQ iOS SDK #

MobileRQ's libMRQSDK is a drop-in static library that provides a simple way to
integrate MobileRQ services into your iOS applications. It includes a pre-compiled 
universal armv7/armv7s/arm64/i386/x86_64 library.

Files

* libMRQSDK-1.4.0.a - The static lib
* *.h - Headers for the lib

For a detailed user guide, see http://mobilerq.com.