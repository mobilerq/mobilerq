//
//  MRQSDK.h
//  MRQSDK
//  http://mobilerq.com
//
//  Copyright (c) 2012-2016 MobileRQ. All rights reserved.
//

#import "MRQContent.h"
#import <CoreFoundation/CoreFoundation.h>
#import <CoreLocation/CoreLocation.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

extern NSString *const kMRQVersion;

/* A notification publish by MRQSDK to NSNotificationCenter defaultCenter each time content is updated. In the NSNotifcation userInfo
   kMRQSDKNotificationKey will be set to the MRQSDK object and kMRQMatchingCountNotificationKey will be set to the count of matching
   content. */
extern NSString *const kMRQContentUpdateNotification;

/* Key for the MRQSDK in NSNotifcation userInfo */
extern NSString *const kMRQSDKNotificationKey;

/* The key for the content match count in NSNotifcation userInfo */
extern NSString *const kMRQMatchingCountNotificationKey;

// keys for requestData
extern NSString *const kMRQUserCity;
extern NSString *const kMRQUserZip;
extern NSString *const kMRQUserGender;
extern NSString *const kMRQUserAge;
extern NSString *const kMRQUserId;
extern NSString *const kMRQTags;
extern NSString *const kMRQProperties;
extern NSString *const kMRQTripFlights;
extern NSString *const kMRQUserTrips;
extern NSString *const kMRQFlightDepartureTime;
extern NSString *const kMRQFlightArrivalTime;
extern NSString *const kMRQFlightOrigin;
extern NSString *const kMRQFlightDestination;
extern NSString *const kMRQFlightAirline;
extern NSString *const kMRQFlightNumber;
extern NSString *const kMRQTripHotels;
extern NSString *const kMRQHotelName;
extern NSString *const kMRQHotelChain;
extern NSString *const kMRQHotelId;
extern NSString *const kMRQHotelCanceled;
extern NSString *const kMRQHotelCheckInTime;
extern NSString *const kMRQHotelCheckOutTime;
extern NSString *const kMRQHotelCheckedIn;
extern NSString *const kMRQHotelCheckedOut;
extern NSString *const kMRQHotelLocation;
extern NSString *const kMRQHotelLocationLatitude;
extern NSString *const kMRQHotelLocationLongitude;
extern NSString *const kMRQHotelLocationCity;
extern NSString *const kMRQHotelLocationRegion;
extern NSString *const kMRQHotelLocationCountry;
extern NSString *const kMRQDateTime;

@class MRQClient;
@protocol MRQSDKDelegate;
@class MRQView;

/**
 The MRQSDK makes it easy for your application to interact with MobileRQ. It performs the following services:

 - Collect data you share and sends it to the MobileRQ service.
 - Process responses from the MobileRQ service.
 - Process push messages sent by the MobileRQ service.
 - Display rich content within the app using custom views MRQContentView, MRQContentTableViewController, and MRQSlotViewController.

 Get the latest SDK and docs at <http://www.mobilerq.com/documentation/ios-sdk/>. Need help? Contact us at <support@mobilerq.com>.
 */
@interface MRQSDK : NSObject <CLLocationManagerDelegate>

/** @name Getting the MRQSDK Instance */

/** A shared instance of the MRQSDK. */
+ (MRQSDK *)shared;

/** @name Getting and Setting the MRQSDK Delegate */

/** The MRQSDKDelegate delegate. */
@property id<MRQSDKDelegate> delegate;

/** @name Configuring MRQSDK */

/** The client ID assigned to your app by the MobileRQ service. */
@property(nonatomic) NSString *clientID;

/** Unique identifier for the end user of the app. Make sure you securely encode personally identifiable information before setting this. */
@property(nonatomic) NSString *customerID;

/** The API host name and scheme. It defaults to the MobileRQ service. Only change this when debugging. */
@property NSString *apiHost;

/** @name Hooking Application Events */

/**
 Set up MRQSDK after application launch.

 This should be called from UIApplication application:didFinishLaunchingWithOptions:. If the app was launched with a remote
 notification, this will receive MobileRQ push messages and set lastNotification. You need to call refresh to download push message
 content.

 @param application The singleton UIApplication object
 @param launchOptions The NSDictionary object received by UIApplication application:didFinishLauchingWithOptions:
 @return YES if the app was launched by a remote notification and it was recognized by MRQSDK, otherwise returns NO.
 @see [UIApplication](https://developer.apple.com/library/ios/documentation/UIKit/Reference/UIApplication_Class/index.html)
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;

/**
 Handle a remote push notification. Call from application:didReceiveRemoteNotification:.
 @param application The singleton UIApplication object
 @param userInfo The NSDictionary object received by the application's UIApplication application:didReceiveRemoteNotification: method
 @return YES if the message was recognized by MRQSDK, otherwise returns NO.
 */
- (BOOL)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo;

/** @name Location Tracking */

/**
 Call this method each time the application receives a location update.
 @param currentLocation A CLLocation object either from CLLocationManager or manually created.
 */
- (void)updateLocation:(CLLocation *)currentLocation;

/**
 Begin monitoring location.

 This monitors location while the app is in the background. Calling this will prompt the user for permission using CLLocationManager
 requestAlwaysAuthorization. The prompt requires you add NSLocationAlwaysUsageDescription in your apps Info.plist file. Once you call
 startMonitoringLocation you no longer need to call updateLocation:.

 @warning *From Apple's developer docs:* Requesting “Always” authorization is discouraged because of the potential negative impacts to
 user privacy. You should request this level of authorization only when doing so offers a genuine benefit to the user.

 @see [CLLocationManager](https://developer.apple.com/library/ios/documentation/CoreLocation/Reference/CLLocationManager_Class/)
 @see [Information Property List Key
 Reference](https://developer.apple.com/library/ios/documentation/General/Reference/InfoPlistKeyReference/Introduction/Introduction.html#//apple_ref/doc/uid/TP40009247)
 @see stopMonitoringLocation
 */
- (void)startMonitoringLocation;

/**
 Begin monitoring location only if the app is authorized.

 Like startMonitoringLocation, this monitors location while the app is in the background. Background monitoring requires "Always"
 authorization. If CLLocationManager authorizationStatus is not kCLAuthorizationStatusAuthorizedAlways this method will do nothing.

 @return YES if authorizationStatus is always, otherwise NO

 @see [CLLocationManager](https://developer.apple.com/library/ios/documentation/CoreLocation/Reference/CLLocationManager_Class/)
 @see startMonitoringLocation
 @see stopMonitoringLocation
 */
- (BOOL)startMonitoringLocationIfAuthorized;

/** Stop monitoring location. */
- (void)stopMonitoringLocation;

/** The last location seen by MRQSDK. This is updated when you use updateLocation: or startMonitoringLocation. */
@property(readonly) CLLocation *lastLocation;

/** @name Push Messaging */

/**
 Register an APN deviceToken with MobileRQ. Call from UIApplication application:didRegisterForRemoteNotificationsWithDeviceToken:.
 @param deviceToken the APN device token
 */
- (void)registerDeviceToken:(NSData *)deviceToken;

/**
 Register a slot with MobileRQ. Content can be assigned to registered slots.
 Register the name when adding a slot view to your app.
 Calling refresh sends the list of registered slot names to MobileRQ.
 @param slotName The slot name to register with MRQ
 */
- (void)registerSlotName:(NSString *)slotName;

/**
 The last remote notification received from the MRQ service. This is set by application:didFinishLaunchingWithOptions: or
 application:didReceiveRemoteNotification: and cleared by refresh.
 */
@property(readonly) NSDictionary *lastNotification;

/** @name Content */

/** The URL for matching content from the last refresh, or nil if there is no matching content. */
@property(readonly) NSURL *matchingContentURL;

/** The matching content from the last refresh. */
@property(readonly) NSArray *matchingContent;

/** The content viewed since the last refresh. */
@property(readonly) NSArray *viewedContent;

/** Refresh context by sending an update to MobileRQ. */
- (void)refresh;

/** Call this method to indicate that all MRQContent was viewed. Views are tracked by the MobileRQ service. */
- (void)trackAllContentViewed;

/**
 Call this method to indicate that MRQContent was viewed. Views are tracked by the MobileRQ service.
 @param mrqContent The MRQContent that was viewed
 */
- (void)trackContentViewed:(MRQContent *)mrqContent;

@end

/**
 The MRQSDK requires you to implement MRQSDKDelegate. The MRQSDKDelegate allows your application to share data with MRQSDK and respond to
 content update events. Optionally, you can recieve errors encountered by MRQSDK.
 */
@protocol MRQSDKDelegate <NSObject>

/**
 The MobileRQ SDK will call this method to request information from the app. Return a dictionary containing data that will be shared with
 the MobileRQ service.

 Example

     - (NSDictionary*) mrqsdkRequestData:(MRQSDK*)mrq {
       NSDictionary *flight = @{
         kMRQFlightDepartureTime : @"2012-07-13T13:00:00Z",
         kMRQFlightAirline : @"UA",
         kMRQFlightAirline : @"LAX",
         kMRQFlightDestination : @"ORD",
         @"ReservationNumber" : @"123456" // flight property
       };
       NSArray *flights = @[ flight ];
       NSDictionary *trip = @{ kMRQTripFlights : flights };
       NSArray *trips = @[ trip ];
       return @{
         kMRQUserTrips : trips,
         kMRQTags: @[ @"demo", @"sample app", @"show lots"],
         kMRQProperties: @{ @"favouriteColour": @"liquorice" }, // context property
       };
     }

 **Request Data Dictionary Keys**

 Request data contains data about the traveler and the trips they have planned.

 Key           |Required| Description
 --------------|:------:|-------------
 kMRQTags      | No     | An array of groups the device belongs to. Offers can match one or more tags.
 kMRQProperties| No     | A dictionary containing context properties.
 kMRQUserTrips | No     | An array of scheduled trips. Also see [kMRQUserTrips Keys](#trip_keys).

 **kMRQUserTrips Keys <a name="trip_keys"></a>**

 A dictionary containing the itinerary for a scheduled trip.

 Key             |Required| Description
 ----------------|:------:|------------
 kMRQTripFlights | No     | An array of scheduled flights. Also see [kMRQTripFlights Keys](#flight_keys).
 kMRQTripHotels  | No     | An array of hotel reservations. Also see [kMRQTripHotels Keys](#hotel_keys)

 **kMRQTripFlights Keys <a name="flight_keys"></a>**

 A dictionary containing the details for a schedule flight.

 Key                     |Required| Description
 ------------------------|:------:|------------
 kMRQFlightDepartureTime | Yes    | The departure time in ISO8601. Example @”2012-07-13T13:00:00-7:00”
 kMRQFlightAirline       | Yes    | The IATA airline code. Example @”UA”
 kMRQFlightNumber        | Yes    | The IATA flight number. Example @”123”
 kMRQFlightOrigin        | No     | The IATA departure airport code. Example @”LAX”
 kMRQFlightDestination   | No     | The IATA arrival airport code. Example @”ORD”

 Any other keys will become flight properties in the MRQ application.

 **kMRQTripHotels Keys <a name="hotel_keys"></a>**

 A dictionary containing the details of a hotel reservation.

 Key                        |Required| Description
 ---------------------------|:------:|------------
 kMRQHotelName              | Yes    | The full name of the hotel. MobileRQ uses the hotel name to match a reservation with a property.
 kMRQHotelChain             | No     | The name of the hotel chain
 kMRQHotelCanceled          | No     | YES if the reservation was canceled
 kMRQHotelCheckInTime       | No     | The check in time in ISO8601. Example @”2012-07-13T13:00:00-7:00”
 kMRQHotelCheckOutTime      | No     | The checkout time in ISO8601. Example @”2012-07-15T13:00:00-7:00”
 kMRQHotelCheckedIn         | No     | YES or No depending on whether checkin has occurred
 kMRQHotelCheckedOut        | No     | YES or No depending on whether checkout has occurred
 kMRQHotelLocation          | No     | The location of the property helps match the reservation with MobileRQ’s database
 kMRQHotelLocationLatitude  | No     | The property latitude
 kMRQHotelLocationLongitude | No     | The property longitude
 kMRQHotelLocationCity      | No     | The hotel city
 kMRQHotelLocationRegion    | No     | The hotel state or province
 kMRQHotelLocationCountry   | No     | The hotel country

 Any other keys will become hotel properties in the MRQ application.

 @param mrq The calling MRQSDK object.
 @return A dictionary containing information for the request data.

 */
- (NSDictionary *)mrqsdkRequestData:(MRQSDK *)mrq;

/**
 Called when content matches request data.
 @param mrq The calling MRQSDK object.
 @param matching The number of matches.
 */
- (void)mrqsdk:(MRQSDK *)mrq updateWithMatches:(NSInteger)matching;

@optional

/**
 Called when an error occurs while updating content
 @param mrq The calling MRQSDK object.
 @param error An NSError describing the error
 */
- (void)mrqsdk:(MRQSDK *)mrq didFailWithError:(NSError *)error;

@end
