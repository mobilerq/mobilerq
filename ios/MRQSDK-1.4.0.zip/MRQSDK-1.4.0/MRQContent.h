//
//  MRQContent.h
//  MRQSDK
//
//  Copyright (c) 2012-2016 MobileRQ. All rights reserved.
//

#import <CoreGraphics/CoreGraphics.h>
#import <Foundation/Foundation.h>

extern const NSString *kMRQContentContentKey;
extern const NSString *kMRQContentContentTypeKey;
extern const NSString *kMRQContentEncodingKey;
extern const NSString *kMRQContentUrlKey;
extern const NSString *kMRQContentViewUrlKey;
extern const NSString *kMRQContentWidthKey;
extern const NSString *kMRQContentHeightKey;
extern const NSString *kMRQContentAudienceIdKey;
extern const NSString *kMRQContentCampaignIdKey;
extern const NSString *kMRQContentCreativeIdKey;
extern const NSString *kMRQContentSlotNameKey;

/** Container for display content sent by the MobileRQ service. */
@interface MRQContent : NSObject

/** The content data. */
@property(readonly) NSString *content;

/** The media type of the content. */
@property(readonly) NSString *contentType;

/** The data sent by the MobileRQ service used to init this content. */
@property(readonly) NSDictionary *data;

/** The content encoding. */
@property(readonly) NSString *encoding;

/** The dimensions of the content in pixels. */
@property(readonly) CGSize size;

/** Width / height. */
- (CGFloat)aspectRatio;

/** The URL to GET when the content is clicked/tapped. This is for tracking purposes. */
@property(readonly) NSURL *url;

/** The URL to GET when the content is viewed. This is for tracking purposes. */
@property(readonly) NSURL *viewUrl;

/** The creative URL defined by the creative. */
@property(readonly) NSURL *creativeUrl;

/** The ID of the matching audience in the MobileRQ service. */
@property(readonly) NSString *audienceId;

/** The ID of the matching campaign in the MobileRQ service. */
@property(readonly) NSString *campaignId;

/** The ID of the matching creative in the MobileRQ service. */
@property(readonly) NSString *creativeId;

/** The name of the slot that the content is associated. */
@property(readonly) NSString *slotName;

/**
 Init content with data sent by the MobileRQ service.
 @param data The data sent by the MobileRQ service.
 */
- (id)initWithData:(NSDictionary *)data;

@end
