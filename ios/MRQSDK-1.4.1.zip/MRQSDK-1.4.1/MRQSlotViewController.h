//
//  MRQSlotViewController.h
//  MRQSDK
//
//  Copyright (c) 2012-2016 MobileRQ. All rights reserved.
//

#import "MRQViewController.h"
#import <UIKit/UIKit.h>

/**
 MRQSlotViewController displays a single piece of matching MRQ content. If MRQ provides more than 1 matching content, only the first (the
 highest ranking) is displayed. MRQSlotViewController only displays content that is designated for the same slot defined by slotName.
 The display area is defined by view. The position and size of the view area can by defined by Interface Builder, by using
 NSLayoutConstraints, or any other method. Content is automatically scaled to fit while maintaining the original aspect ratio.
 If the content aspect ratio and the aspect ratio of the MRQSlotViewController view do not match, the content is cropped such that there is
 no unused space.
 */
@interface MRQSlotViewController : MRQViewController

@end
